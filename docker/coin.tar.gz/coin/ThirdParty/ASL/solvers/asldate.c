long ASLdate_ASL = 20180528;
